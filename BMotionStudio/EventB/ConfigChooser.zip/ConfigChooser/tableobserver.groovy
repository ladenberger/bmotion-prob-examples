import de.bmotionstudio.gef.editor.*;
import de.bmotionstudio.gef.editor.model.*;
import de.bmotionstudio.gef.editor.observer.*;
import de.bmotionstudio.gef.editor.util.*;

public class CloneObserver implements IObserver {
   
   	def listOfClonedControls = []
   
    public void check(Animation a, BControl c) {
    
    	def parentControl = c.getParent()
    	
    	def petSet = BMSUtil.parseExpression("sel",c,a)
   
   		petSet = petSet.replace("}","")
   		petSet = petSet.replace("{","")
   		def arr = petSet.split(', ')
   		
   		println arr
    	println arr.size()
    
    }
        
}